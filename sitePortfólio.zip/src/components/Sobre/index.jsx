import '../Sobre/style.css';


export default function Sobre(){
    return(
        <div className="sobre" id="sobre">
        <h2>Sobre mim</h2>

        <div className="linha__vertical"></div>
            <p>Atualmente com 26 anos, nascido e criado em Espumoso 
                Rio Grande do Sul, sempre fui intrigado 
                e fascinado por tecnologia,  comecei minha jornada
                estudando primeiramente hardware ainda na adolescencia e 
                com o passar dos anos fui me interessando cada vez
                mais pela software e programação, no momento
                estou  cursando análise e desenvolvimento de sistemas na UNINTER
                e buscando uma primeira expêriencia profissional na área.<br/><br/>
                
                Através deste site busco mostrar minha evolução na caminhada 
                para aprender e evoluir na área do desenvolvimento web.<br/><br/>
                
                Quando não estou estudando ou programando, você pode me achar 
                jogando ou lendo alguma fantasia desconhecida e de baixa qualidade
                que eu irei adorar por algum motivo.<br/><br/>
                
                Muito obrigado por visitar meu site, se você tiver algum comentário ou avaliação 
                não hesite em entrar em contato.
            </p>

        </div>
    )
}